package com.starline.purchase.order.config.constant;
/*
@Author hakim a.k.a. Hakim Amarullah
Java Developer
Created on 10/15/2024 11:10 PM
@Last Modified 10/15/2024 11:10 PM
Version 1.0
*/

public class RoleConstant {

    public static final String ADMIN = "ADMIN";
    public static final String USER = "USER";
    private RoleConstant() {

    }
}
